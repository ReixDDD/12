@echo off
chcp 65001 >nul
title Print Calculator Launcher
cd /d "%~dp0"
call npm run dev
